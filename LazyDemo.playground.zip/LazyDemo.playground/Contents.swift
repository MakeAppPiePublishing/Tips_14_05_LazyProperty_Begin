//The Joys of Lazy Properties
//An exercise file for iOS Development Tips Weekly
//A weekly course on LinkedIn Learning for iOS developers
// Season 14 (Q2 2021) video 05
// by Steven Lipton (C)2021, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//  For more code, go to http://bit.ly/AppPieGithub



struct PizzaList{
    var pizzaNames:[String]
    
    var sortReverse:[String]{
        return self.pizzaNames.sorted(by:{ $0 > $1})
    }
    init(_ names:[String]){
        self.pizzaNames = names
    }
    func sortNames()->[String]{
        return pizzaNames.sorted(by:{ $0 < $1})
    }
}

var menu = PizzaList(["Huli Chicken","BBQ Chicken","Pepperoni","Longboard Veggie","Quattro Formaggi"])
menu.pizzaNames

